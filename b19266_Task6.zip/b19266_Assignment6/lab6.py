"""Name: Shivani Pandey
   Roll no. : b19266
   Contact Number: 9917466008"""
   
#importing libraries
import parser
import numpy as np
import pandas as pd
from statsmodels.tsa.ar_model import AutoReg
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
import statsmodels.api as sm
import datetime


df=pd.read_csv("datasetA6_HP.csv",parse_dates=True)       # reading data csv file
#Q1.
print("Question 1:")

#a

df["Date"]=pd.to_datetime(df["Date"],dayfirst=True)       #to convert string datetime to python datetime
fig, ax = plt.subplots(figsize=(6, 6))
ax.plot(df["Date"],df["HP"])
ax.set(xlabel="Date",ylabel="Power Consumed")

plt.xticks(rotation='45')
plt.show()

#b
print()
print("(b)")

df1=df.shift(1)[1:]    # generate time sequence with one day lag
print("Correlation coefficient between x_t and x_t-1 : ",df["HP"].autocorr(lag=1))   #calculating autocorrelation

#c
fig, ax = plt.subplots(figsize=(6, 6))
x=df["HP"][1:]

ax.scatter(df["HP"][1:],df1["HP"])
ax.set(xlabel="Time Sequence",ylabel="One Day Lag Time Sequence")
plt.show()

#d
df2=df.shift(2)[2:]     #generating time sequence with two days lag
df3=df.shift(3)[3:]	#generating time sequence with three days lag
df4=df.shift(4)[4:]	#generating time sequence with four days lag
df5=df.shift(5)[5:]	#generating time sequence with five days lag
df6=df.shift(6)[6:]	#generating time sequence with six days lag
df7=df.shift(7)[7:]	#generating time sequence with seven days lag

corr=[]			#making a list of correlation values for diff time lags
for i in range(1,8):
    corr.append(df["HP"].autocorr(lag=i))   

fig, ax = plt.subplots(figsize=(6, 6))
ax.plot(range(1,8),corr,color="red")
ax.set(xlabel="Lag Value", ylabel="Pearson Correlation")
plt.title("Autocorrelation")
plt.show()

#e

sm.graphics.tsa.plot_acf(df["HP"].values, lags=7)
plt.xlabel("Lag Value")
plt.ylabel("Pearson Correlation")
plt.show()

print("-----------------------------------------------------------------------------")
#Q2
print("Question 2:")

print()

dflag=pd.DataFrame(df[len(df)-250:].values)        	# separating training data

d1=pd.DataFrame(df[len(df)-251:len(df)-1].values)	#test data

d=pd.concat([d1[1],dflag[1]],axis=1)			#dataframe that contains t and t-1 values 

d.columns=["t-1","t"]
d.index=dflag[0]


def model_persistence(x):				# persistence model		
    return x
X_test_label=d["t"]
X_test=d["t-1"]
pred=[]

for i in X_test:					
    pred.append(model_persistence(i))
print("RMSE of Persistance Model  : ",mean_squared_error(X_test_label,pred)**(0.5))
print("----------------------------------------------------------------------------------------------------")

#Q3

print()
print("Question 3:")

X=df.values
[x_train, x_test] =X[1:len(X)-250],X[len(X)-250:]		#separating training and test data
x_train=pd.DataFrame(x_train)
x_test=pd.DataFrame(x_test)

model=AutoReg(x_train[1].values, 5,old_names=True)		#generating autoregression model
model_fit=model.fit()

predictions = model_fit.predict(start=len(x_train), end=len(x_train)+len(x_test)-1, dynamic=False)  #predicting values of test data

print("RMSE OF AR(5) MODEL :", mean_squared_error(x_test[1],predictions)**0.5)
plt.figure()
plt.scatter(x_test[1],predictions,)
plt.xlabel("Original Test Data")
plt.ylabel("Predicted Test Data")

plt.show()

x=pd.Series(x_train[1])
x=x.astype(float)

#(b)
print()
print()

print("(b)")
lag=[1,5,10,15,25]
opt_lag=0
opt_rmse=100
for i in lag:					# generating auto regression models for different lag values
    mod = AutoReg(x_train[1].values, i, old_names=True)
    mod_fit = mod.fit()

    predict = mod_fit.predict(start=len(x_train), end=len(x_train) + len(x_test) - 1, dynamic=False)

    print("RMSE OF AR("+str(i)+")", ":" ,mean_squared_error(x_test[1], predict) ** 0.5)   # calculating rmse
    if mean_squared_error(x_test[1], predict)**0.5<opt_rmse:      #predicting optimum lag value
        opt_rmse=mean_squared_error(x_test[1], predict)**0.5
        opt_lag=i
T=len(x_train)

#c
print()

optimal_lag=0
for i in range(1,250):
    if x.autocorr(lag=i)<2/(T**0.5):                #predicting optimum lag value
        optimal_lag=i-1
        break
opt_mod = AutoReg(x_train[1].values, optimal_lag, old_names=True)
opt_mod_fit = opt_mod.fit()

opt_predict = opt_mod_fit.predict(start=len(x_train), end=len(x_train) + len(x_test) - 1, dynamic=False)

print("Heurestic value for Optimal number of Lag:",optimal_lag)
print("RMSE for Optimal Lags:" ,mean_squared_error(x_test[1], opt_predict) ** 0.5)
#d

print()
print("Optimal Lags in 3(b) is :",opt_lag)
print("Optimal Lags in 3(c) is :",optimal_lag)
print("RMSE of Optimal Lag in 3(b) is:", opt_rmse)
print("RMSE of Optimal Lag in 3(c) is:",mean_squared_error(x_test[1], opt_predict) ** 0.5)
