"""Name: Shivani Pandey
   Roll no. : b19266
   Contact Number: 9917466008"""

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
data = pd.read_csv('landslide_data3.csv')

## Question 1
print("Question1:")
attributes = ['temperature', 'humidity', 'pressure', 'rain', 'lightavgw/o0', 'lightmax', 'moisture'] #list of attributes 

def outliers_change(attr):
    p =np.quantile(attr,0.25)
    q =np.quantile(attr,0.75)
    r =np.median(attr)
    for i in range(len(attr)):
        if (attr.loc[i]<(p-1.5*(q-p))) or (attr.loc[i]>(q+ 1.5*(q-p))):

            attr.loc[i]=r
for i in attributes:
    outliers_change(data[i])

data1=data.copy()
def norma(attr):
    x =np.max(attr)
    y =np.min(attr)
    print('\nMin. value ',y,'Max. value',x)
    for i in range(len(attr)):
        attr.loc[i] = (attr.loc[i] - y) / (x - y) * (9 - 3) + 3

    print('Min. value ',np.min(attr),'Max. value ',np.max(attr))
for i in attributes:
    norma(data[i])

mean_data =data1.mean()
stddevt_data =data1.std()
def standa(attr):
    j =np.mean(attr)
    k =np.std(attr)
    for i in range(len(attr)):
        attr.loc[i]= (attr.loc[i]-j)/k

for i in attributes:
    standa(data1[i])
mean_data_std=data1.mean()
stddevt_data_std =data1.std()
print('Mean of Data before standardization\n',mean_data,'\nMean of Data after standardization\n',mean_data_std)
print('Standarad Deviation before standardization\n',stddevt_data,'\nStandarad Deviation after standardization\n',stddevt_data_std)
print()    
print("---------------------------------------------------------------------------------------- -")


## Question2 

print("Question2 :")
nu = [0, 0]
sigma = [[5, 10], [10, 13]]
D = np.random.multivariate_normal(nu, sigma, 1000).T
print(D)
plt.figure(figsize=(6,6))
plt.scatter(D[0],D[1])
plt.title("Scatter plot of matrix D")
plt.xlabel('X1')
plt.ylabel('X2')
plt.xlim([-20,20])
plt.ylim([-20,20])
plt.show()

eigenvalues, eigenvectors = np.linalg.eig(np.cov(D))
origin = [0, 0]
print(eigenvalues)
print(eigenvectors)
eigenvector1 = eigenvectors[:,0]
eigenvector2 = eigenvectors[:,1]
plt.figure(figsize=(6,6))
plt.scatter(D[0],D[1])
plt.quiver(origin, origin, eigenvector2, eigenvector1, scale =4)
plt.xlabel("X1")
plt.ylabel("Y1")
plt.title("Scatter plot of data with eigen directions")
plt.xlim([-20,20])
plt.ylim([-20,20])
plt.show()

project1 = np.dot(D.T, eigenvector1)
plt.figure(figsize=(6,6))
plt.scatter(D[0],D[1])
plt.quiver(origin, origin, eigenvector2, eigenvector1, scale=4)
plt.scatter(project1*eigenvectors[0][0],project1*eigenvectors[1][0],color='green')
plt.title('Scatter plot of data projected on eigenvector1 superimposed on eigenvectors')
plt.xlabel('X1')
plt.ylabel('X2')
plt.xlim([-20,20])
plt.ylim([-20,20])
plt.show()

project2 = np.dot(D.T, eigenvector2)
plt.figure(figsize=(6,6))
plt.scatter(D[0],D[1])
plt.quiver(origin, origin, eigenvector2, eigenvector1, scale=4)
plt.scatter(project1*eigenvectors[0][0],project1*eigenvectors[1][0],color='green')
plt.title('Scatter plot of data projected on eigenvector2 superimposed on eigenvectors')
plt.xlabel('X1')
plt.ylabel('X2')
plt.xlim([-20,20])
plt.ylim([-20,20])
plt.show()

recons =np.dot(D.T,eigenvectors)
recons1 =np.dot(recons ,eigenvectors.T)
recons_error =np.square(np.subtract(recons, recons1)).mean()   #reconstruction error using mean square error
print(recons_error)
print("---------------------------------------------------------------------------------")

##Question3

print("Question3:")
data1 = data1.drop(['stationid','dates'],axis=1)

#part(a)
from sklearn.decomposition import PCA    #importing sklearn library for Principle componenet analysis 
pca =PCA(n_components=2)
pca.fit(data1)
data1_tr =pca.transform(data1)
plt.scatter(data1_tr[:,0],data1_tr[:,1])   #scatter plot of 2 dimensional transformed data
plt.xlabel('1st principle comp.')
plt.ylabel('2nd principle comp.')
plt.title('Reduced dimesional data')
plt.show()

data2 = data1.copy()
eigenval3,eigenvec3= np.linalg.eig(np.cov(data2.T))   #finding eigen values and vectors using inbuilt function
print(eigenval3)
print(eigenvec3)
u =pca.components_
pvar =pca.explained_variance_
print('Eigen value of PC 1:',eigenval3[0])
print('Vairance of PC 1:',pvar[0])
print('Eigen value of PC 2:',eigenval3[1])
print('Variance of PC 2:',pvar[1])

#part(b)
eigenv_list =[]  
for i in eigenval3:
    eigenv_list.append(i)
eigenv_list.sort(reverse=True)    #list containing eigen values in descending order
plt.bar(range(1,8),eigenv_list)   #plot of all the eigen values 
plt.xlabel('Number of Eigen Values')
plt.ylabel(' Eigen Value')
plt.show()

#part(c)

def rmse(g,h):  #creating function for the calculation of root mean square error
    return (sum(((g-h)*2).sum(axis=1))/len(g))*0.5
data3 =pca.inverse_transform(data1_tr)
print("RMSE:",rmse(data1, data2))
RMSE =[]
for i in range(1,8):
    pca =PCA(n_components=i)
    pca.fit(data1)
    data1_p =pca.transform(data1)
    data1_n =pca.inverse_transform(data1_p)
    RMSE.append(rmse(data1,data1_n))

print(RMSE)
plt.bar(range(1,8),RMSE)
plt.plot(range(1,8),RMSE)
plt.scatter(range(1,8),RMSE)
plt.xlabel('Principal components')
plt.ylabel('Root mean square error')
plt.show()