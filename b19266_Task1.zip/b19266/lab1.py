"""Name: Shivani Pandey
   Roll no. : b19266
   Contact Number: 9917466008"""

import pandas as pd 
data = pd.read_csv('landslide_data3.csv')  #Reading csv file

## Question1
import statistics

attributes = ['temperature', 'humidity', 'pressure', 'rain', 'lightavgw/o0', 'lightmax', 'moisture'] #list of attributes 
print("Question 1:")
for i in attributes:               #finding mean, mode, median, standard deviation, minimum value and maximum value of all attributes
    print("For ",i)
    print("The mean", i ," is ", statistics.mean(data[i]))
    print("The median value of ", i ," is ", statistics.median(data[i]) )
    print("The mode of ", i ," is ", statistics.mode(data[i]))
    print("The standard deviation of ", i, " is ", statistics.stdev(data[i]))
    print("The minimum ", i , " is ", min(data[i]))
    print("The maximum ", i , " is ", max(data[i]))
    print(" ")


## Question2

import matplotlib.pyplot as plt 
print("Question 2:")
print("part a")
rain_attributes = ['temperature', 'humidity', 'pressure', 'lightavgw/o0', 'lightmax', 'moisture'] #list of attributes except rain
for i in rain_attributes:       #scatter plot of rain with other attributes
    plt.scatter(data['rain'],data[i])
    plt.xlabel('Rain')
    plt.ylabel(i)
    plt.title('Scatter plot')
    plt.show()
print("part b")
temperature_attributes = ['humidity', 'pressure', 'rain', 'lightavgw/o0', 'lightmax', 'moisture']   #list of attributes except temperature 
for i in temperature_attributes:      #scatter plot of temperature with other attributes
    plt.scatter(data['temperature'],data[i])
    plt.xlabel('Temperature')
    plt.ylabel(i)
    plt.title('Scatter plot')
    plt.show()

## Question3

import numpy as np 
print("Question 3:")
for i in rain_attributes:         #correlation coeffecient between rain and other attributes
    print("The pearson correlation coeffecient between rain and ", i ," is ", np.corrcoef(data['rain'], data[i])[0][1])
    print("")
for i in temperature_attributes:    #correlation coeffecient between temperature and other attributes
    print("The pearson correlation coeffecient between temperature and ", i ," is ", np.corrcoef(data['temperature'],data[i])[0][1])
    print("")


## Question4
print("Question 4:")
plt.hist(data['rain'],bins = 10 )  #histogram of rain
plt.xlabel('Rain in ml')
plt.ylabel('Frequency')
plt.show()

plt.hist(data['moisture'],bins = 10)  #histogram of moisture
plt.xlabel('Moisture %')
plt.ylabel('Frequency')
plt.show()

## Question5
print("Question 5:")
data2 = data.groupby('stationid')         #grouping data with respect to stationid
stationids = list(set(data['stationid']))   #list of all stationids
stationids.sort()                          #sorting stationids 
for i in stationids: 
    rain = data2.get_group(i)               #finding group data of corresponding stationid
    plt.hist(rain['rain'])                  #plotting histogram of rain attribute of respective group
    plt.title(i)
    plt.xlabel('Rain (in ml)')
    plt.ylabel('Frequency')
    plt.show()

## Question6
print("Question 6:")
plt.boxplot(data['rain'])               #plotting boxplot of Rain
plt.title("Boxplot of Rain")
plt.xlabel("Rain")
plt.show()
plt.boxplot(data['moisture'])           #plotting boxplot of Moisture
plt.title("Boxplot of Moisture")
plt.xlabel("Moisture")
plt.show()