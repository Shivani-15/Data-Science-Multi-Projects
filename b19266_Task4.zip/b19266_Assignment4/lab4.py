"""Name: Shivani Pandey
   Roll no. : b19266
   Contact Number: 9917466008"""


import numpy as np   #importing libraries
import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score

df = pd.read_csv("seismic_bumps1.csv")    #reading data
df = df.drop(columns = df.keys()[8:16])


#Question 1
print("Question 1:")
x = df[df.columns[:10]]   
y = df[df.columns[-1]]     #separating class labels

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.3, random_state = 42, shuffle = True)   #splitting data into train and test

train = pd.concat([x_train, y_train], axis = 1)
test = pd.concat([x_test, y_test], axis = 1)

train.to_csv("seismic-bumps-train.csv")  #creating csv files
test.to_csv("seismic-bumps-test.csv")

#part a & b
for i in [1, 3, 5]:
    knn = KNeighborsClassifier(n_neighbors = i)    #performing knn
    knn.fit(x_train, y_train)
    predict = knn.predict(x_test)
    print("\nFor k = ", i)
    print("Confusion Matrix : \n", confusion_matrix(y_test, predict))
    print("Accuracy Score : ", accuracy_score(y_test, predict))


#Question 2
print("Question2: ")

min = x_train.min()
max = x_train.max()
diff = max - min
normal_xtrain = (x_train - min)/diff      #to normalise train data

min = x_test.min()
max = x_test.max()
diff = max - min
normal_xtest = (x_test - min)/diff        # to normalise test data

normal_train = pd.concat([normal_xtrain, y_train], axis = 1)
normal_test = pd.concat([normal_xtest, y_test], axis = 1)

normal_train.to_csv("seismic-bumps-train-Normalised.csv")   #creating csv files
normal_test.to_csv("seismic-bumps-test-Normalised.csv")

#part a & b
for i in [1, 3, 5]:
    knn = KNeighborsClassifier(n_neighbors = i)
    knn.fit(normal_xtrain, y_train)              # knn on normalised data
    predict = knn.predict(normal_xtest)
    print("\nFor k = ", i)
    print("Confusion Matrix : \n", confusion_matrix(y_test, predict))
    print("Accuracy Score : ", accuracy_score(y_test, predict))


#Question 3
print("Question 3:")

train0 = train[train["class"] == 0]
train1 = train[train["class"] == 1]
xtrain0 = train0[train0.columns[:-1]]
xtrain1 = train1[train1.columns[:-1]]

cov0 = np.cov(xtrain0.T)
cov1 = np.cov(xtrain1.T)

mean0 = np.mean(xtrain0)
mean1 = np.mean(xtrain1)

def likelihood(x, m, cov):        #function to calculate likelihood
    ex = np.exp(-0.5*np.dot(np.dot((x-m).T, np.linalg.inv(cov)), (x-m)))
    return(ex/((2*np.pi)*5 * (np.linalg.det(cov))*0.5))

prior0 = len(train0)/len(train)        #calculating prior probabities
prior1 = len(train1)/len(train)

predict = []
for i, x in x_test.iterrows():
    p0 = likelihood(x, mean0, cov0) * prior0
    p1 = likelihood(x, mean1, cov1) * prior1
    if p0 > p1:
        predict.append(0)
    else:
        predict.append(1)

print("\nFor Bayes classifier")
print("Confusion Matrix : \n", confusion_matrix(y_test, predict))      #calculating confusion matrix after bayes
print("Accuracy Score : ", accuracy_score(y_test, predict))

