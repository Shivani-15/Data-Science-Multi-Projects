"""Name: Shivani Pandey
   Roll no. : b19266
   Contact Number: 9917466008"""

import pandas as pd 
import matplotlib.pyplot as plt
data = pd.read_csv('pima_indians_diabetes_miss.csv')  #Reading csv file
df1 = pd.DataFrame(data)                              #dataframe of file with missing values

## Question1
print("Question 1:")
count = df1.isnull().sum()  #sum the count of missing values in each column
count.plot.bar()                # plot the Pandas series
plt.title("Missing values in attributes")
plt.show()
print("---------------------------------------------------------")
print()

## Question2
print("Question 2:")
##part(a)
print("part(a):")
total_row_drop=0
print("Row numbers deleted:")
for i in df1.index:
    if df1.loc[i].isnull().sum() >=3:     #checking if the number of null attributes in a row is equal to or greater than 3 or not
        print(i)
        total_row_drop +=1                 # increasing the number of total rows deleted by 1 for each deleted row
        df1.drop(i, inplace=True)          #dropping the rows with 3 or more null attributes
print("The total number of rows deleted which had 3 or more attribute values missing: ",total_row_drop)

##part(b)
print("part(b):")        
rows_drop=0
print("Row numbers deleted:")
for i in df1.index:
    if pd.isnull(df1.loc[i]['class'])==True:  #checking if the row attribute has any value or not
        print(i)
        df1.drop(index=i, axis=0, inplace=True) #deleting the row if class value is missing
        rows_drop +=1                           #increasing the total rows drop by 1 for each row deleted
print("Total rows dropped which had no value in class attribute :",rows_drop)
print("---------------------------------------------------------")
print()

## Question3
print("Question 3:")
print()
null_count = df1.isnull().sum()             #summing the count of null values of each attribute
total_null = null_count.sum()               # summing the counts of total null values of attributes
print("Count of missing values in each attribute:", null_count)
print("Total null count:",total_null)
print("---------------------------------------------------------")
print()

## Question 4
data2 = pd.read_csv('pima_indians_diabetes_original.csv')   # reading data from file with original values
df2 = pd.DataFrame(data2)                                   # dataframe of data with original values

def compare(df, df2):                                       # function to print the values of edited and original file
    print("For edited file:")    
    for i in df:
        print("Mean value of",i," is:",df[i].mean())
        print("Median value of",i," is:",df[i].median())
        print("Mode value of",i," is:",df[i].mode())
        print("Standard Deviation of",i," is:",df[i].std())

    print()
    
    print("For original file:") 
    for i in df2:
        print("Mean value of",i," is:",df2[i].mean())
        print("Median value of",i," is:",df2[i].median())
        print("Mode value of",i," is:",df2[i].mode())
        print("Standard Deviation of",i," is:",df2[i].std())
    print()   

def rmse(df,df2,dict):                                          #function to find rmse
    for i in df:
        sum = 0
        for j in dict[i]:                                       # j is the indexes of rows deleted corresponding to each attribute
            sum = sum + (df.loc[j][i] - df2.loc[j][i])**2       # adding the square of differnce of original and replaced value
        if len(dict[i])>0:    
            sum = sum/len(dict[i])                              # dividing the sum by the number of replaced values
            print("RMSE of ", i,"is", (sum)**0.5)               # printing the square root of sum, i.e., RMSE
        else:
            continue

dct = {}
print("Question 4:")
print()
df3 = df1.copy()                                            # creating a shallow copy of dataframe of missing values 
# part(a)
print("part a:")
print("Missing values replaced by mean:")                                           
for i in df1:
    dct[i] = []                                             # creating an empty list corresponding to each attribute in dictionary
    for j in df1.index:
        if pd.isnull(df1.loc[j][i])==True:                  #checking if a row has missing value of an attribute
            dct[i].append(j)                                # if missing, appending it's row number, i.e, index in the list corresponding to the attribute in dictionary
    df1[i].fillna(value=df1[i].mean(), inplace =True)       # filling all the missing values of the attribute with mean value
compare(df1, df2)                                           # comparing the mean, median, mode of edited data and original data
print()        
rmse(df1,df2,dct)                                           # calculating rmse 
print()

# part(b)
print("part b:")
print("Missing values replaced using linear interpolation:")
df3.interpolate(method = 'linear', axis =0, inplace = True)  # fillingthe missing values using linear interpolation in shallow copy of missing value dataframe
compare(df3, df2)                                            # comparing the mean, median, mode of edited data and original data
print()
rmse(df3,df2,dct)                                            # calculating rmse    
print("------------------------------------------------------------------")

## Question 5
print("Question 5:")
attributes = ['Age', 'BMI']

for i in attributes:
    print("Boxplot of ",i)        
    plt.boxplot(df3[i])                 # plotting initial boxplots of Age and BMI
    print()
    plt.title(i)
    plt.show()        
    q1 = df3[i].quantile(0.25)          # calculating first quartile
    q3 = df3[i].quantile(0.75)          # calculting second quartile
    iqr = q3 - q1                       # interquartile range
    print("Outliers in ",i)
    for j in df3.index :
        if df3.loc[j][i]<(q1-(1.5)*iqr) or df3.loc[j][i]>(q3+(1.5)*iqr):        #checking whether a value lies in outlier range
            print(df3.loc[j][i])                                # if outlier, prinitng it
            df3.loc[j][i]=df3[i].median()                       # replacing the outlier values with median values
    print("Boxplot of ",i,"after replacing outliers with median value:")                
    plt.boxplot(df3[i])                 # plotting boxplots after replacing outlier values with median values
    print()
    plt.title(i)
    plt.show()  

##############################################################################################333    