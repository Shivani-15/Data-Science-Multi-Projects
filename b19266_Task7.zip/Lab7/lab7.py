"""Name: Shivani Pandey
   Roll no. : b19266
   Contact Number: 9917466008"""
   
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.cluster import DBSCAN
from sklearn import metrics
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import cdist
import scipy as sp
from scipy import spatial as spatial

trainData = pd.read_csv("mnist-tsne-train.csv")
testData = pd.read_csv("mnist-tsne-test.csv")
train = trainData.iloc[:, :-1]
trainClass = trainData[trainData.columns[-1]]
test = testData.iloc[:, :-1]
testClass = testData[testData.columns[-1]]

# Q1
print("QUESTION-1")

kmeans = KMeans(n_clusters=10, random_state=42)
kmeans.fit(train)
kmeans_prediction = kmeans.predict(train)
cluster_centre_knn = pd.DataFrame(kmeans.cluster_centers_)


def purity_score(y_true, y_pred):
    contingency_matrix = metrics.cluster.contingency_matrix(y_true,
                                                            y_pred)  # confusion matrix C  such that C(i,j) is the number of samples in true class i and in predicted class j.
    row_ind, col_ind = linear_sum_assignment(-contingency_matrix)
    return np.sum(contingency_matrix[row_ind, col_ind]) / np.sum(contingency_matrix)
colors=['b','g','r','c','m','y','gold','lawngreen','yellowgreen','tan','pink','darkkhaki','maroon','olivedrab','dodgerblue','midnightblue','orange','firebrick','chocolate','cadetblue','slateblue']
def plot_function(X,N,prediction,type):
    for i in range(N):
        data=X[prediction == i]
        plt.scatter(data[data.columns[0]],data[data.columns[1]],c=colors[i],label="Cluster "+str(i+1))
        if type!="DBSCAN":
            plt.scatter(data.mean()[0],data.mean()[1],marker="*",s=120,color="black")
    if type=="DBSCAN":
        data = X[prediction == -1]
        plt.scatter(data[data.columns[0]], data[data.columns[1]], c=colors[20], label="Noise")
    plt.legend()
    plt.xlabel("Dimension 1")
    plt.ylabel("Dimension 2")
    plt.title(type)
    plt.show()
    plt.figure()

# a
print("(a)")
print()
plot_function(train,10,kmeans_prediction,"KNN")

# b
print("(b)")
print()

print("Purity Score for KNN Training Data :-", purity_score(trainClass, kmeans_prediction))

# c
print("(c)")
print()
kmeans_test_prediction = kmeans.predict(test)
plot_function(test,10,kmeans_test_prediction,"KNN")


# d
print("(d)")
print()

print("Purity Score for KNN Test Data :-", purity_score(testClass, kmeans_test_prediction))

# Q2

print("QUESTION-2")

gmm = GaussianMixture(n_components=10, random_state=42)
gmm.fit(train)

# a
print("(a)")
print()

GMM_prediction = gmm.predict(train)
cluster_centre_gmm = pd.DataFrame(gmm.means_)

plot_function(train,10,GMM_prediction,"GMM")
# b
print("(b)")
print()

print("Purity Score for GMM Training Data :-", purity_score(trainClass, GMM_prediction))

# c
print("(c)")
print()

GMM_test_prediction = gmm.predict(test)
plot_function(test,10,GMM_test_prediction,"GMM")

# d
print("(d)")
print()

print("Purity Score for GMM Test Data :-", purity_score(testClass, GMM_test_prediction))

# Q3

print("QUESTION-3")

dbscan_model = DBSCAN(eps=5, min_samples=10)
dbscan_model.fit(train)

# a
print("(a)")
print()

DBSCAN_prediction = dbscan_model.labels_
plot_function(train,max(dbscan_model.labels_)+1,DBSCAN_prediction,"DBSCAN")

# b
print("(b)")
print()

print("Purity Score for DBSCAN Training Data :-", purity_score(trainClass, DBSCAN_prediction))

# c
print("(c)")
print()


def dbscan_predict(dbscan_mod, X_new, metric=spatial.distance.euclidean):
    y_new = np.ones(shape=len(X_new), dtype=int) * -1
    for j, x_new in enumerate(X_new):
        for i, x_core in enumerate(dbscan_mod.components_):
            if metric(x_new, x_core) < dbscan_mod.eps:
                y_new[j] = dbscan_mod.labels_[dbscan_mod.core_sample_indices_[i]]
                break
    return y_new


DBSCAN_test_prediction = dbscan_predict(dbscan_model, np.array(test), metric=spatial.distance.euclidean)
plot_function(test,max(dbscan_model.labels_)+1,DBSCAN_test_prediction,"DBSCAN")

# d
print("(d)")
print()

print("Purity Score for DBSCAN Test Data :-", purity_score(testClass, DBSCAN_test_prediction))

# Bonus Questions
print( "Bonus Questions")
print()
print()
print( "A")


K = [2, 5, 8, 12, 18, 20]
Distortion = []
for k in K:
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(train)
    kmeans_prediction = kmeans.predict(train)


    plot_function(train,k,kmeans_prediction,"KNN")
    plt.title("KNN Clustering Training Data for k= " + str(k))


    print("Purity Score for KNN Training Data for K = ", k, " :-", purity_score(trainClass, kmeans_prediction))


    kmeans_test_prediction = kmeans.predict(test)
    plot_function(test,k,kmeans_test_prediction,"KNN")
    plt.title(" KNN Clustering Test Data for k= " + str(k))


    cdist(train, kmeans.cluster_centers_, 'euclidean')
    print("Distorion for k =",k," is :-   ",sum(np.min(cdist(train, kmeans.cluster_centers_, 'euclidean'), axis=1)) / train.shape[0])
    Distortion.append(sum(np.min(cdist(train, kmeans.cluster_centers_, 'euclidean'), axis=1)) / train.shape[0])

plt.figure()
plt.plot(K, Distortion, 'bx-')
plt.xlabel('Values of K')
plt.ylabel('Distortion')
plt.xticks(K)
plt.title('The Elbow Method using Distortion')
plt.show()
plt.figure()
Likelihood = []
for k in K:
    gmm = GaussianMixture(n_components=k, random_state=42)
    gmm.fit(train)
    GMM_prediction = gmm.predict(train)

    Likelihood.append(gmm.lower_bound_)
    plot_function(train,k,GMM_prediction,"GMM")

    print("Purity Score for GMM Training Data for K = ", k, " :-", purity_score(trainClass, GMM_prediction))
    print("Max Log Likelihood for k =", k, " is :-   ",gmm.lower_bound_)
    GMM_test_prediction = gmm.predict(test)
    plot_function(test,k,GMM_test_prediction,"GMM")



plt.figure()
plt.plot(K, Likelihood, 'bx-')
plt.xlabel('Values of K')
plt.xticks(K)
plt.ylabel('Log Likelihood')
plt.title('The Elbow Method using Log Likelihood')

print("#" * 20, "B", "#" * 50)
eps=[1,5,10]
min_samples=[1,10,30,50]
for i in eps:
    dbscan_model=DBSCAN(eps=i,min_samples=10)
    dbscan_model.fit(train)
    DBSCAN_prediction = dbscan_model.labels_
    plot_function(train,max(dbscan_model.labels_)+1,DBSCAN_prediction,"DBSCAN")

    print("Purity Score for DBSCAN Training Data eps=",i,":-", purity_score(trainClass, DBSCAN_prediction))
    DBSCAN_test_prediction = dbscan_predict(dbscan_model, np.array(test), metric=spatial.distance.euclidean)
    plot_function(test,max(dbscan_model.labels_)+1,DBSCAN_test_prediction,"DBSCAN")
for i in min_samples:
    dbscan_model = DBSCAN(eps=5, min_samples=i)
    dbscan_model.fit(train)
    DBSCAN_prediction=dbscan_model.labels_
    plot_function(train,max(dbscan_model.labels_)+1,DBSCAN_prediction,"DBSCAN")

    print("Purity Score for DBSCAN Training Data min_sample=", i, ":-", purity_score(trainClass, DBSCAN_prediction))
    DBSCAN_test_prediction = dbscan_predict(dbscan_model, np.array(test), metric=spatial.distance.euclidean)

    plot_function(test,max(dbscan_model.labels_)+1,DBSCAN_test_prediction,"DBSCAN")