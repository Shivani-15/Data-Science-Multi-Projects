"""Name: Shivani Pandey
   Roll no. : b19266
   Contact Number: 9917466008"""
   
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


print("PART-A")
print()
print("QUESTION-1")
sbtrain=pd.read_csv("seismic-bumps-train.csv")
sbtest=pd.read_csv("seismic-bumps-test.csv")
X_train_0=sbtrain[sbtrain["class"]==0].drop(["class"],axis=1)
X_train_1=sbtrain[sbtrain["class"]==1].drop(["class"],axis=1)
X_train_label=sbtrain["class"]
X_test=sbtest[sbtest.columns[:-1]]
X_test_label=sbtest["class"]

from sklearn.mixture import GaussianMixture
from  sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix


prior_0 = len(X_train_0) / (len(X_train_1) + len(X_train_0))
prior_1 = len(X_train_1) / (len(X_train_1) + len(X_train_0))



def likelihood(X,gmm):
    return np.exp(gmm.score_samples((X)))


def P(x0,x1):
    return prior_0*x0 +prior_1*x1


def posterior(X,gmm0,gmm1):
    y=[]
    for i,j in zip(likelihood(X,gmm0),likelihood(X,gmm1)):
        a=i*prior_0/P(i,j)
        b=j*prior_1/P(i,j)
        if a>b:
            y.append(0)
        else:
            y.append(1)
    return y


import warnings

warnings. filterwarnings('ignore')

acc=[]
q=[2,4,8,16]

for i in q:
    gmm0 = GaussianMixture(n_components=i, covariance_type='full',random_state=42)
    gmm1 = GaussianMixture(n_components=i, covariance_type='full',random_state=42)
    gmm0.fit(X_train_0)
    gmm1.fit(X_train_1)

    y_pred = posterior(X_test,gmm0,gmm1)

    print("Confusion Matrix for Q=",i)
    print(confusion_matrix(X_test_label, y_pred))


    print("Classification Accuracy for Q=", i)
    print(accuracy_score(X_test_label, y_pred))
    acc.append(accuracy_score(X_test_label, y_pred))
    print("#"*25)

acc2=acc[0]
acc4=acc[1]
acc8=acc[2]
acc16=acc[3]
m=max(acc)

#Q2
print("#"*20,"QUESTION-2","#"*30)
l1=["k1","k3","k5","k1_normalised","k3_normalised","k5_normalised","Bayes Classifier UniModal","Bayes Classifier GMM (Multimodal)" ]
l2=[0.904639,0.930412,0.927835,0.904639,0.93170,0.939433,0.914233,m]
df=pd.DataFrame(l2,index=l1,columns=["Classification Accuracy"])

print(df)

print("----------------------------------------------------------------------------------------------------------")
print("PART-B")

data=pd.read_csv("atmosphere_data.csv")

X = data.drop(["temperature"],axis=1)
X_label = data["temperature"]

from sklearn.model_selection import train_test_split

[X_train, X_test, X_label_train, X_label_test] = train_test_split(X, X_label, test_size=0.3, random_state=42, shuffle=True)


atmtest = pd.concat((X_test, X_label_test), axis=1)
atmtrain = pd.concat((X_train, X_label_train), axis=1)
atmtest.to_csv('atmosphere-test.csv')
atmtrain.to_csv('atmosphere-train.csv')


#Q1
d=atmtrain.sort_values(["pressure"])
d1=atmtest.sort_values(["pressure"])

#(a)

from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

x_train=d["pressure"].values.reshape(-1,1)
x_train_label=d["temperature"]
x_test=d1["pressure"].values.reshape(-1,1)
x_test_label=d1["temperature"]


regr=LinearRegression()
regr.fit(x_train,x_train_label)
y_pred_train=regr.predict(x_train)
y_pred_test=regr.predict(x_test)



plt.scatter(x_train,x_train_label, color ='b',marker="x")
plt.plot(x_train, y_pred_train, color= 'g')
plt.xlabel("Pressure")
plt.ylabel("Temperature")
plt.title("Best fit line on the Training Data")
plt.show()



#(b)
print("Q1")
print("(b)")
def rmse(y1,y2):
    return (((y1-y2)**2).sum()/(len(y2)))**(0.5)


rmse_train=rmse(y_pred_train,x_train_label)
print("Prediction accuracy on the training data using root mean squared error :",rmse_train)

print("#################################################################################################")
#(c)
print("(c)")
rmse_test=rmse(y_pred_test,x_test_label)
print("Prediction accuracy on the test data using root mean squared error :",rmse_test)
print(mean_squared_error(x_test_label,y_pred_test)**0.5)
print("##################################################################################################")

#(d)
plt.figure()
plt.ylim(16,27)
plt.xlim(5,35)
plt.scatter(x_test_label,y_pred_test,marker='x')
plt.xlabel("Actual Temperature")
plt.ylabel("Predicted Temperature")
plt.title("Scatter plot Test Data")
plt.show()



#Q2

from sklearn.preprocessing import PolynomialFeatures
p=[2,3,4,5]
rmse_train_poly=[]
rmse_test_poly=[]


for i in p:
    poly=PolynomialFeatures(degree=i)
    x_train_poly=poly.fit_transform(x_train)
    x_test_poly=poly.fit_transform(x_test)
    regr.fit(x_train_poly,x_train_label)
    y_pred_train_poly=regr.predict(x_train_poly)
    y_pred_test_poly=regr.predict(x_test_poly)
    rmse_train_poly.append(rmse(y_pred_train_poly,x_train_label))
    rmse_test_poly.append(rmse(y_pred_test_poly,x_test_label))


print("Q2")
#(a)
print("(a)")
for i in range(2,6):
    print("Prediction Accuracy on the training data for p=",i," :",rmse_train_poly[i-2])

plt.figure()
plt.bar(p,rmse_train_poly)
plt.xlabel("Degree of Polynomial")
plt.ylabel("RMSE")
plt.title("Prediction Accuracy on Training Data")
plt.show()

print("#######################################################################################################")
#(b)
print("(b)")

for i in range(2,6):
    print("Prediction Accuracy on the test data for p=",i," :",rmse_test_poly[i-2])

plt.figure()
plt.bar(p,rmse_test_poly)
plt.xlabel("Degree of Polynomial")
plt.ylabel("RMSE")
plt.title("Prediction Accuracy on Test Data")
plt.show()

print("############################################################################################################")

#(c)
i_min=rmse_test_poly.index(min(rmse_test_poly))+2


poly = PolynomialFeatures(degree=i_min)
x_train_poly = poly.fit_transform(x_train)
x_test_poly = poly.fit_transform(x_test)
regr.fit(x_train_poly, x_train_label)
y_pred_train_poly = regr.predict(x_train_poly)
y_pred_test_poly = regr.predict(x_test_poly)



plt.figure()
plt.scatter(x_train, x_train_label)
plt.plot(x_train, y_pred_train_poly, color = 'g')
plt.xlabel("Pressure Value")
plt.ylabel("Temperature")
plt.title("Degree of Polynomial "+str(i_min))
plt.show()
#(d)


print("(d)")
poly=PolynomialFeatures(degree=i_min)
x_train_poly=poly.fit_transform(x_train)
x_test_poly=poly.fit_transform(x_test)
regr.fit(x_train_poly,x_train_label)
best_y_pred_test_poly=regr.predict(x_test_poly)
print("Prediction Accuracy of test data for best degree :"+str(i_min)+" ->",rmse(best_y_pred_test_poly,x_test_label))


plt.figure()
plt.scatter(x_test_label,best_y_pred_test_poly,mark3er="x")
plt.xlabel("Actual temperature")
plt.ylabel("Predicted Temperature")
plt.title(" Scatter Plot for best Degree of Polynomial-> "+str(i_min))
plt.show()